# THE JACKET MAKER (Pakistan Edition) - Full MERN Stack E-Commerce & Bespoke Atelier

A luxury, fully-responsive MERN Stack eCommerce web application inspired by [The Jacket Maker PK](https://www.thejacketmaker.pk/) with an elevated **Obsidian & Artisan Cognac Leather** theme.

---

## ✨ Key Features

1. **Atelier Storefront & Outerwear Collections**:
   - Men's Leather Jackets (Biker, Bomber, Cafe Racer, Shearling & Aviator, Trench Coats, Varsity).
   - Women's Leather Jackets (Moto, Tailored Blazers, Merino Shearling, Belted Trench).
   - Leather Bags & Accessories (Overland Duffels, Messenger Briefcases, Cashmere-Lined Gloves).

2. **Interactive Bespoke Studio ("Design Your Own Jacket")**:
   - Step 1: Base Silhouette (Cafe Racer, Double Rider Biker, Aviator Shearling, Long Trench, Varsity, Blazer)
   - Step 2: Leather Material (Full-Grain Sheepskin, Heavy Cowhide, Goatskin Suede, Merino Wool Shearling)
   - Step 3: Colorway (Obsidian Black, Vintage Cognac, Distressed Espresso, Midnight Navy, Oxblood Burgundy, Olive)
   - Step 4: Hardware & Metal Zippers (Antiqued Brass, Polished Silver, Matte Gunmetal)
   - Step 5: Interior Lining (Quilted Thermal Satin, Crimson Silk, Heritage Tartan Cotton, Sherpa)
   - Step 6: Personal Monogramming (Hot-stamp initials / custom name patch)
   - Step 7: Custom Body Tailoring (Chest, Shoulders, Sleeve Length, Waist, Back Length, Height, Weight)
   - Real-time dynamic price calculator in **PKR** and **USD**
   - Direct "Add Bespoke Jacket to Cart" or "Request 1-on-1 Artisan Consultation"

3. **Made-to-Measure (Free Sizing Option)**:
   - On every product detail page, clients can choose between standard sizes (XS to 3XL) or input their exact body measurements for free pattern customization.
   - Interactive Size Guide Modal with detailed illustrated measuring steps in inches and centimeters.

4. **Pakistan-Centric Courier & Payment Features**:
   - **Cash on Delivery (COD)** supported across all cities (Lahore, Karachi, Islamabad, Rawalpindi, Faisalabad, Multan, Peshawar, Sialkot, Quetta, etc.).
   - Direct Online Bank Transfer (Meezan Bank, HBL, Bank Alfalah).
   - JazzCash & EasyPaisa Mobile Wallet support.
   - Free Doorstep Express Courier delivery nationwide.

5. **Slide-Over Cart Drawer & Promo Code Engine**:
   - Persistent bag storage via LocalStorage.
   - Live delivery progress indicator.
   - Promo discount codes (e.g. `JACKET10` for 10% off, `BESPOKE15` for 15% off).

6. **Order Tracking System (`/track-order`)**:
   - Track by code (`TJM-PK-XXXXXX`) or Order ID.
   - 5-stage visual timeline: Order Received -> Pattern Drafting -> Hand-Stitching -> Courier Dispatch -> Delivered.

7. **Authentication & Client Dashboard (`/dashboard`)**:
   - JWT authentication with secure bcrypt password hashing.
   - Customer Order History with live status tags.
   - Persistent Saved Measurements Profile for quick 1-click tailored reorders.

8. **Master Atelier Admin Suite (`/admin`)**:
   - Live analytics: Total Revenue (PKR), Active Orders, Bespoke Inquiries, Catalog Products.
   - Order management: Update status (Processing, In Crafting, Dispatched, Delivered) and attach courier tracking codes.
   - Custom Inquiries tab: Review bespoke custom jacket designs, measurements, and customer notes.
   - Product catalog management: Add new leather jackets or delete existing products.

---

## 🛠️ Technology Stack

- **Frontend**: React 18 (Vite 6), Tailwind CSS, Lucide React Icons, React Router DOM v7, Axios, Canvas Confetti.
- **Backend**: Node.js, Express.js, MongoDB (Mongoose), JWT, BcryptJS, Multer, Morgan, CORS.
- **Resilient Fallback Storage**: Built-in JSON storage layer (`dataStore.js`) automatically protects against database drops or local offline development.

---

## 🚀 Getting Started

### Prerequisites:
- Node.js (v18+)
- MongoDB (Optional: The application automatically connects to MongoDB `mongodb://127.0.0.1:27017/the-jacket-maker` and has a seamless local fallback)

### 1. Run Backend Server:
```bash
cd server
npm install
node seed.js      # Seeds products, demo users, and reviews into MongoDB
node server.js    # Starts API on http://localhost:5000
```

### 2. Run Frontend Client:
```bash
cd client
npm install
npm run dev       # Starts Vite dev server on http://localhost:5173
```

---

## 🔑 Demo & Admin Credentials

| Role | Email | Password |
|---|---|---|
| **Atelier Admin** | `admin@thejacketmaker.pk` | `admin123` |
| **Demo Customer** | `umar@thejacketmaker.pk` | `customer123` |
*(One-click quick login buttons are also provided in the Sign-In modal!)*
