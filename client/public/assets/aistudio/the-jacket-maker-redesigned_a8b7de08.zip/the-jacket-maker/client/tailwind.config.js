/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: { DEFAULT: '#1B1D22', soft: '#3B3F47', muted: '#6A6F78' },
        line: { DEFAULT: '#E4E3DF', strong: '#CFCDC7' },
        stone: { DEFAULT: '#F4F3F0', deep: '#EAE8E3' },
        saddle: {
          50: '#FAF3EE',
          100: '#F2E3D7',
          500: '#A5622F',
          600: '#8A4B25',
          700: '#6F3B1C',
        },
        sale: '#B3261E',
        ok: '#1E7B4B',
        star: '#D9A21B',
      },
      fontFamily: {
        sans: ['Figtree', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
        display: ['"Barlow Semi Condensed"', 'Figtree', 'system-ui', 'sans-serif'],
      },
      keyframes: {
        fadeIn: { from: { opacity: '0' }, to: { opacity: '1' } },
        slideInRight: { from: { transform: 'translateX(100%)' }, to: { transform: 'translateX(0)' } },
        slideInLeft: { from: { transform: 'translateX(-100%)' }, to: { transform: 'translateX(0)' } },
        slideUp: { from: { transform: 'translateY(16px)', opacity: '0' }, to: { transform: 'translateY(0)', opacity: '1' } },
      },
      animation: {
        'fade-in': 'fadeIn .2s ease-out both',
        'slide-in-right': 'slideInRight .25s ease-out both',
        'slide-in-left': 'slideInLeft .25s ease-out both',
        'slide-up': 'slideUp .25s ease-out both',
      },
    },
  },
  plugins: [],
}
