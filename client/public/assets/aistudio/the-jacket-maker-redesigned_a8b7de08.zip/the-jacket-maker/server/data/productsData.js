export const sampleProducts = [
  // MEN'S JACKETS
  {
    name: "Ionic Black Cafe Racer Leather Jacket",
    slug: "ionic-black-cafe-racer-leather-jacket",
    category: "Men",
    subCategory: "Cafe Racer",
    description: "Handcrafted from full-grain sheepskin with a semi-aniline finish. Features a snap-button band collar, zippered cuffs, and precision quilt detailing across the shoulders.",
    pricePKR: 54900,
    originalPricePKR: 68000,
    priceUSD: 195,
    discountPercent: 19,
    leatherType: "Full Grain Sheepskin",
    hardware: "Antiqued Gunmetal YKK Zippers",
    lining: "Quilted Thermal Silk-Satin Blend",
    rating: 4.9,
    numReviews: 142,
    inStock: 25,
    featured: true,
    bestSeller: true,
    isNewArrival: false,
    colors: [
      { name: "Obsidian Black", hex: "#111111" },
      { name: "Vintage Cognac", hex: "#7E4822" },
      { name: "Midnight Navy", hex: "#1A2530" }
    ],
    sizes: ["XS", "S", "M", "L", "XL", "2XL", "3XL"],
    madeToMeasureAvailable: true,
    images: [
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1520975954732-35dd22299614?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1521223890158-f9f7c3d5d504?auto=format&fit=crop&w=900&q=80"
    ],
    specs: {
      outerShell: "100% Real Full-Grain Sheepskin",
      leatherFinish: "Semi-Aniline Waxed Lustre",
      closure: "Original Heavy-Duty YKK Brass Front Zipper",
      collar: "Band Collar with Dual Snap Clasp",
      cuffs: "Zippered Gusset Cuffs",
      pockets: "Two zippered chest pockets, two hand-warmer zip pockets, two interior welt pockets"
    }
  },
  {
    name: "Inferno Distressed Brown Biker Leather Jacket",
    slug: "inferno-distressed-brown-biker-leather-jacket",
    category: "Men",
    subCategory: "Biker",
    description: "Rugged double rider motorcycle jacket in hand-distressed cowhide. Built for adventure, with asymmetrical zip closure, notch lapels, and adjustable waist buckle belt.",
    pricePKR: 59900,
    originalPricePKR: 74900,
    priceUSD: 215,
    discountPercent: 20,
    leatherType: "Hand-Distressed Cowhide",
    hardware: "Antiqued Brass Heavy Hardware",
    lining: "Heritage Tartan Cotton Twill",
    rating: 4.85,
    numReviews: 98,
    inStock: 18,
    featured: true,
    bestSeller: true,
    isNewArrival: false,
    colors: [
      { name: "Distressed Espresso", hex: "#4A2E1B" },
      { name: "Burnished Tan", hex: "#9E6437" }
    ],
    sizes: ["S", "M", "L", "XL", "2XL"],
    madeToMeasureAvailable: true,
    images: [
      "https://images.unsplash.com/photo-1520975954732-35dd22299614?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=900&q=80"
    ],
    specs: {
      outerShell: "Hand-Rubbed 1.2mm Heavy Cowhide",
      leatherFinish: "Vintage Pull-Up Distressed",
      closure: "Asymmetric Diagonal Brass Zipper",
      collar: "Notch Lapel with Press-Stud Snaps",
      cuffs: "Deep Zipper Expander Cuffs",
      pockets: "3 Exterior Zip Pockets, 1 Coin Flap Pocket, 2 Internal Passport Pockets"
    }
  },
  {
    name: "Airman Shearling Aviator Flight Bomber",
    slug: "airman-shearling-aviator-flight-bomber",
    category: "Men",
    subCategory: "Shearling",
    description: "Authentic WW2 B3 flight jacket crafted from thick plush merino sheepskin shearling. Heavy buckle throat latch, storm flap, and genuine wool fleece lining for extreme warmth.",
    pricePKR: 79900,
    originalPricePKR: 98000,
    priceUSD: 285,
    discountPercent: 18,
    leatherType: "Merino Sheepskin Shearling",
    hardware: "Matte Bronze Antiqued Hardware",
    lining: "100% Genuine Dense Merino Wool Fleece",
    rating: 5.0,
    numReviews: 76,
    inStock: 12,
    featured: true,
    bestSeller: false,
    isNewArrival: true,
    colors: [
      { name: "Dark Chocolate & Cream", hex: "#2E1C14" },
      { name: "Raw Umber & Ivory", hex: "#5C3A21" }
    ],
    sizes: ["S", "M", "L", "XL", "2XL", "3XL"],
    madeToMeasureAvailable: true,
    images: [
      "https://images.unsplash.com/photo-1548883354-7622d03aca27?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=900&q=80"
    ],
    specs: {
      outerShell: "Real Thick Shearling Sheepskin Nappa",
      leatherFinish: "Weatherproof Matt Nappa Coating",
      closure: "Heavy Gauge Metal Front Zip with Wind Storm Flap",
      collar: "Double Buckled Shearling Turn-Down Collar",
      cuffs: "Turn-back Shearling Wool Cuffs",
      pockets: "Two Deep Hand-Warmer Pockets, 1 Inside Zip Pocket"
    }
  },
  {
    name: "Lavendula Suede Biker Jacket",
    slug: "lavendula-suede-biker-jacket",
    category: "Men",
    subCategory: "Biker",
    description: "Ultra-soft Italian goatskin suede with a velvet-touch hand feel. Cut in a contemporary slim biker silhouette with silver-tone accents.",
    pricePKR: 52900,
    originalPricePKR: 64900,
    priceUSD: 189,
    discountPercent: 18,
    leatherType: "Italian Velvet Goatskin Suede",
    hardware: "Polished Nickel Silver Zippers",
    lining: "Breathable Cupro Silk",
    rating: 4.78,
    numReviews: 64,
    inStock: 15,
    featured: false,
    bestSeller: false,
    isNewArrival: true,
    colors: [
      { name: "Smoky Charcoal", hex: "#33373B" },
      { name: "Caramel Suede", hex: "#A86D3E" }
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    madeToMeasureAvailable: true,
    images: [
      "https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=900&q=80"
    ],
    specs: {
      outerShell: "100% Genuine Goat Suede Leather",
      leatherFinish: "Silky Velvet Nap Finish",
      closure: "Asymmetric Silver YKK Zipper",
      collar: "Biker Lapel with Nickel Snaps",
      cuffs: "Zipped Gusseted Cuffs",
      pockets: "3 Front Zippered Pockets, 1 Inner Pocket"
    }
  },
  {
    name: "Legacy Long Leather Trench Coat",
    slug: "legacy-long-leather-trench-coat",
    category: "Men",
    subCategory: "Trench Coats",
    description: "The definitive full-length double-breasted leather trench. Built from supple lightweight sheepskin, complete with storm shields, epaulets, and a cinched leather belt.",
    pricePKR: 74900,
    originalPricePKR: 89000,
    priceUSD: 268,
    discountPercent: 16,
    leatherType: "Supple Lightweight Sheepskin",
    hardware: "Horn Buttons & Solid Brass Buckle",
    lining: "Full Satin Twill Lining",
    rating: 4.92,
    numReviews: 53,
    inStock: 10,
    featured: false,
    bestSeller: false,
    isNewArrival: false,
    colors: [
      { name: "Gothic Black", hex: "#151515" },
      { name: "Mahogany Brown", hex: "#42281D" }
    ],
    sizes: ["S", "M", "L", "XL", "2XL"],
    madeToMeasureAvailable: true,
    images: [
      "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=900&q=80"
    ],
    specs: {
      outerShell: "100% Full Grain Supple Sheepskin",
      leatherFinish: "Matte Smooth Aniline",
      closure: "Double Breasted 8-Button Closure",
      collar: "Wide Peak Trench Collar with Throat Hook",
      cuffs: "Buckled Cuff Straps",
      pockets: "Two Deep Slash Pockets, Two Concealed Interior Pockets"
    }
  },
  {
    name: "Velocity Wool & Leather Varsity Jacket",
    slug: "velocity-wool-and-leather-varsity-jacket",
    category: "Men",
    subCategory: "Varsity",
    description: "Classic American collegiate aesthetic with 24oz Melton wool torso and buttery top-grain cowhide leather sleeves. Ribbed knit trims with vintage stripe accents.",
    pricePKR: 44900,
    originalPricePKR: 54900,
    priceUSD: 160,
    discountPercent: 18,
    leatherType: "Top Grain Cowhide Sleeves + Melton Wool",
    hardware: "Enamelled Snap Buttons",
    lining: "Diamond Quilted Poly-Satin",
    rating: 4.88,
    numReviews: 89,
    inStock: 30,
    featured: true,
    bestSeller: true,
    isNewArrival: false,
    colors: [
      { name: "Forest Green & Cream", hex: "#1E3F2E" },
      { name: "Jet Black & White", hex: "#1C1C1C" },
      { name: "Navy & Tan", hex: "#1B2A47" }
    ],
    sizes: ["XS", "S", "M", "L", "XL", "2XL"],
    madeToMeasureAvailable: true,
    images: [
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1520975954732-35dd22299614?auto=format&fit=crop&w=900&q=80"
    ],
    specs: {
      outerShell: "Heavy Melton Wool Body & Cowhide Leather Sleeves",
      leatherFinish: "Smooth Natural Grain Leather",
      closure: "Heavy Snap Button Front",
      collar: "2x2 Striped Ribbed Stand Knit Collar",
      cuffs: "Elastic Striped Rib Knit",
      pockets: "Two Genuine Leather Trim Welt Pockets, Two Inside Pockets"
    }
  },

  // WOMEN'S JACKETS
  {
    name: "Allure Asymmetric Black Biker Leather Jacket",
    slug: "allure-asymmetric-black-biker-leather-jacket",
    category: "Women",
    subCategory: "Biker",
    description: "The quintessential women's leather moto jacket. Tailored for a flattering feminine drape with an asymmetric zipper, lapel snap fastenings, and polished hardware.",
    pricePKR: 51900,
    originalPricePKR: 64900,
    priceUSD: 185,
    discountPercent: 20,
    leatherType: "Full Grain Sheepskin",
    hardware: "Polished Silver Hardware",
    lining: "Silky Crimson Red Satin",
    rating: 4.94,
    numReviews: 165,
    inStock: 22,
    featured: true,
    bestSeller: true,
    isNewArrival: false,
    colors: [
      { name: "Noir Black", hex: "#0E0E0E" },
      { name: "Oxblood Red", hex: "#5C171E" },
      { name: "Warm Chestnut", hex: "#6E3F25" }
    ],
    sizes: ["XS", "S", "M", "L", "XL", "2XL"],
    madeToMeasureAvailable: true,
    images: [
      "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=900&q=80"
    ],
    specs: {
      outerShell: "100% Genuine Semi-Aniline Sheepskin",
      leatherFinish: "Supple Butter-Soft Hand",
      closure: "Heavy Asymmetrical Metal Zip",
      collar: "Studded Biker Lapels",
      cuffs: "Zippered Wrist Closures",
      pockets: "3 Exterior Zippered Pockets, 1 Interior Welt Pocket"
    }
  },
  {
    name: "Empress Tailored Leather Blazer",
    slug: "empress-tailored-leather-blazer",
    category: "Women",
    subCategory: "Blazers",
    description: "Sartorial elegance meets modern edge. Precision-tailored silhouette with structured shoulders, single horn button fastening, and waist darting that contours effortlessly.",
    pricePKR: 56900,
    originalPricePKR: 69900,
    priceUSD: 205,
    discountPercent: 18,
    leatherType: "Plonge Nappa Leather",
    hardware: "Handmade Horn Button",
    lining: "Bemberg Silk Lining",
    rating: 4.89,
    numReviews: 82,
    inStock: 16,
    featured: true,
    bestSeller: false,
    isNewArrival: true,
    colors: [
      { name: "Glossy Onyx", hex: "#121212" },
      { name: "Rich Cognac", hex: "#94552A" },
      { name: "Ivory Cream", hex: "#EBE3D7" }
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    madeToMeasureAvailable: true,
    images: [
      "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=900&q=80"
    ],
    specs: {
      outerShell: "100% Ultra-Supple Italian Plonge Nappa",
      leatherFinish: "Natural High-End Satin Grain",
      closure: "Single Breasted Dual Button",
      collar: "Notched Lapel Collar",
      cuffs: "Four-Button Surgeon Cuffs",
      pockets: "Dual Flap Hip Pockets, Chest Welt Pocket"
    }
  },
  {
    name: "Frost Velvet Shearling Cropped Aviator",
    slug: "frost-velvet-shearling-cropped-aviator",
    category: "Women",
    subCategory: "Shearling",
    description: "Cropped silhouette lined with plush cloud-soft merino wool shearling. Features oversized storm collar, dual leather buckle fasteners, and heavy burnished zippers.",
    pricePKR: 74900,
    originalPricePKR: 88900,
    priceUSD: 265,
    discountPercent: 15,
    leatherType: "Double-Faced Merino Shearling",
    hardware: "Burnished Brass Buckles & Zips",
    lining: "100% High-Density Merino Fur",
    rating: 5.0,
    numReviews: 61,
    inStock: 9,
    featured: true,
    bestSeller: false,
    isNewArrival: true,
    colors: [
      { name: "Dark Walnut & Cream", hex: "#3B2219" },
      { name: "Pitch Black & Grey", hex: "#1B1B1B" }
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    madeToMeasureAvailable: true,
    images: [
      "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=900&q=80"
    ],
    specs: {
      outerShell: "100% Genuine Double-Faced Sheepskin Shearling",
      leatherFinish: "Cracked Distress Finish",
      closure: "Asymmetric Metal Zip Closure",
      collar: "Double Buckle Shearling Collar",
      cuffs: "Exposed Shearling Cuffs",
      pockets: "Two Waist Zip Pockets"
    }
  },
  {
    name: "Victoria Belted Long Trench Coat",
    slug: "victoria-belted-long-trench-coat",
    category: "Women",
    subCategory: "Trench Coats",
    description: "Iconic cinematic trench coat cut from light buttery sheepskin. Reaches below the knee with dramatic lapels, wrist cinchers, and an obi-style sash belt.",
    pricePKR: 72900,
    originalPricePKR: 89000,
    priceUSD: 260,
    discountPercent: 18,
    leatherType: "Lightweight Nappa Sheepskin",
    hardware: "Covered Leather Buckles",
    lining: "Tonal Viscose Jacquard",
    rating: 4.9,
    numReviews: 44,
    inStock: 11,
    featured: false,
    bestSeller: false,
    isNewArrival: false,
    colors: [
      { name: "Midnight Black", hex: "#0E0E0E" },
      { name: "Caramel Toffee", hex: "#A86A3D" }
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    madeToMeasureAvailable: true,
    images: [
      "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=900&q=80"
    ],
    specs: {
      outerShell: "100% Genuine Butter Sheepskin",
      leatherFinish: "Sleek Aniline Polish",
      closure: "Double-Breasted Button Front with Tie Belt",
      collar: "Exaggerated Notched Trench Lapels",
      cuffs: "Buckled Adjustable Wrist Straps",
      pockets: "Deep Inset Side Pockets"
    }
  },

  // BAGS & ACCESSORIES
  {
    name: "The Overland Leather Weekender Duffel",
    slug: "the-overland-leather-weekender-duffel",
    category: "Bags",
    subCategory: "Leather Bags",
    description: "Built for lifetime voyages. Hand-stitched full-grain buffalo leather with brass rivets, reinforced base studs, dedicated shoe compartment, and padded shoulder strap.",
    pricePKR: 38900,
    originalPricePKR: 48000,
    priceUSD: 139,
    discountPercent: 19,
    leatherType: "Full Grain Water-Resistant Buffalo Leather",
    hardware: "Solid Antiqued Brass Hardware",
    lining: "Waterproof Waxed Canvas",
    rating: 4.95,
    numReviews: 120,
    inStock: 25,
    featured: true,
    bestSeller: true,
    isNewArrival: false,
    colors: [
      { name: "Vintage Saddle Tan", hex: "#8A502C" },
      { name: "Dark Espresso", hex: "#382318" },
      { name: "Coal Black", hex: "#1A1A1A" }
    ],
    sizes: ["45 Liters (Carry-On Approved)"],
    madeToMeasureAvailable: false,
    images: [
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=900&q=80"
    ],
    specs: {
      outerShell: "Full-Grain Vegetable-Tanned Buffalo Hide",
      leatherFinish: "Waxed Pull-Up Patina Developing",
      closure: "Heavy Two-Way YKK Solid Brass Zipper",
      collar: "Reinforced Rolled Leather Carry Handles",
      cuffs: "Removable Padded Leather Shoulder Strap",
      pockets: "Separate Zippered Shoe Tunnel, 2 External Zip Pockets, Laptop Sleeve"
    }
  },
  {
    name: "Artisan Full-Grain Leather Messenger Briefcase",
    slug: "artisan-full-grain-leather-messenger-briefcase",
    category: "Bags",
    subCategory: "Leather Bags",
    description: "The ultimate executive bag. Accommodates up to 16\" laptops with cushioned microfiber divider, quick-release push clips behind vintage buckles, and trolley strap.",
    pricePKR: 34900,
    originalPricePKR: 42000,
    priceUSD: 125,
    discountPercent: 16,
    leatherType: "Full Grain Cowhide",
    hardware: "Brushed Gunmetal Hardware",
    lining: "Heavyweight Cotton Herringbone",
    rating: 4.88,
    numReviews: 73,
    inStock: 20,
    featured: false,
    bestSeller: false,
    isNewArrival: true,
    colors: [
      { name: "Whiskey Cognac", hex: "#9E6032" },
      { name: "Obsidian Black", hex: "#171717" }
    ],
    sizes: ["Standard 16-inch Laptop Size"],
    madeToMeasureAvailable: false,
    images: [
      "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80"
    ],
    specs: {
      outerShell: "100% Genuine Full Grain Cowhide",
      leatherFinish: "Semi-Aniline Protective Finish",
      closure: "Dual Flap Push Locks with Adjustable Buckles",
      collar: "Comfort Grip Top Leather Handle",
      cuffs: "Detachable Cotton-Webbing & Leather Shoulder Strap",
      pockets: "Padded 16\" Laptop Compartment, Pen Slots, Key Carabiner, Rear Magnetic Magazine Slot"
    }
  },
  {
    name: "Cashmere Lined Sheepskin Driving Gloves",
    slug: "cashmere-lined-sheepskin-driving-gloves",
    category: "Accessories",
    subCategory: "Accessories",
    description: "Handcrafted from tactile touchscreen-compatible sheepskin nappa with 100% pure Mongolian cashmere knit lining. Snug wrist snap and perforation ventilation.",
    pricePKR: 12900,
    originalPricePKR: 16900,
    priceUSD: 46,
    discountPercent: 23,
    leatherType: "Touchscreen Nappa Sheepskin",
    hardware: "Branded Antique Snap Button",
    lining: "100% Pure Mongolian Cashmere",
    rating: 4.96,
    numReviews: 104,
    inStock: 40,
    featured: false,
    bestSeller: true,
    isNewArrival: false,
    colors: [
      { name: "Classic Black", hex: "#141414" },
      { name: "British Tan", hex: "#9C5F2B" }
    ],
    sizes: ["S", "M", "L", "XL"],
    madeToMeasureAvailable: false,
    images: [
      "https://images.unsplash.com/photo-1516762689617-e1cffcef479d?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1520975954732-35dd22299614?auto=format&fit=crop&w=900&q=80"
    ],
    specs: {
      outerShell: "Ultra-Soft Aniline Sheepskin Nappa",
      leatherFinish: "Full Precision Touchscreen Conductive Leather",
      closure: "Elasticated Shirred Wrist with Snap Clasp",
      collar: "Perforated Knuckle Vents for Breathability",
      cuffs: "Reinforced Piped Seams",
      pockets: "Includes Embossed Velvet Travel Pouch"
    }
  }
];
