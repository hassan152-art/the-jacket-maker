import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import morgan from 'morgan';
import mongoose from 'mongoose';
import path from 'path';
import { fileURLToPath } from 'url';

import authRoutes from './routes/authRoutes.js';
import productRoutes from './routes/productRoutes.js';
import orderRoutes from './routes/orderRoutes.js';
import customRoutes from './routes/customRoutes.js';
import reviewRoutes from './routes/reviewRoutes.js';
import statsRoutes from './routes/statsRoutes.js';
import uploadRoutes from './routes/uploadRoutes.js';
import { initStorage } from './data/dataStore.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));
app.use(morgan('dev'));

// Static files for uploaded images
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Mount API routes
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/custom-studio', customRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/api/stats', statsRoutes);
app.use('/api/upload', uploadRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    atelier: 'The Jacket Maker (Pakistan Edition)',
    version: '2.0.0',
    database: mongoose.connection.readyState === 1 ? 'MongoDB Connected' : 'Resilient High-Speed JSON Store Active',
    timestamp: new Date().toISOString()
  });
});

// Root welcome route
app.get('/', (req, res) => {
  res.send('The Jacket Maker MERN API is running in luxury mode.');
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ message: `Route ${req.originalUrl} not found on atelier server` });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled server error:', err.stack || err.message);
  res.status(500).json({
    message: err.message || 'Internal Server Error in Jacket Maker API'
  });
});

// Connect Database & Start Server
async function startServer() {
  await initStorage();

  const mongoURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/the-jacket-maker';
  try {
    await mongoose.connect(mongoURI, {
      serverSelectionTimeoutMS: 2000
    });
    console.log('✅ Connected to MongoDB at:', mongoURI);
  } catch (err) {
    console.warn('⚠️  Local MongoDB not running. Seamlessly activated resilient built-in JSON persistence layer.');
    console.warn('   All product catalog, users, orders, and custom studio inquiries will persist smoothly.');
  }

  app.listen(PORT, () => {
    console.log(`=======================================================`);
    console.log(`✨ THE JACKET MAKER - MERN BACKEND SERVER RUNNING`);
    console.log(`🌐 URL: http://localhost:${PORT}`);
    console.log(`🛍️ API Health: http://localhost:${PORT}/api/health`);
    console.log(`👔 Admin Login: admin@thejacketmaker.pk | admin123`);
    console.log(`👤 Customer Demo: umar@thejacketmaker.pk | customer123`);
    console.log(`=======================================================`);
  });
}

startServer();
