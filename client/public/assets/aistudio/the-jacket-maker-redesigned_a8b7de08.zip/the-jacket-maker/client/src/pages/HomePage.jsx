import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Ruler, Scissors, Truck, Layers, PackageCheck } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { Stars, imgFallback } from '../components/ui';
import { useCurrency } from '../context/CurrencyContext';
import api from '../services/api';

const TABS = [
  { key: 'All', test: () => true },
  { key: 'Men', test: (p) => p.category === 'Men' },
  { key: 'Women', test: (p) => p.category === 'Women' },
  { key: 'Shearling', test: (p) => p.subCategory === 'Shearling' },
  { key: 'Bags', test: (p) => p.category === 'Bags' },
];

const TILES = [
  {
    label: 'Men',
    to: '/shop?category=Men',
    img: 'https://images.unsplash.com/photo-1520975954732-35dd22299614?auto=format&fit=crop&w=800&q=80',
    test: (p) => p.category === 'Men',
  },
  {
    label: 'Women',
    to: '/shop?category=Women',
    img: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=800&q=80',
    test: (p) => p.category === 'Women',
  },
  {
    label: 'Shearling',
    to: '/shop?subCategory=Shearling',
    img: 'https://images.unsplash.com/photo-1548883354-7622d03aca27?auto=format&fit=crop&w=800&q=80',
    test: (p) => p.subCategory === 'Shearling',
  },
  {
    label: 'Bags',
    to: '/shop?category=Bags',
    img: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80',
    test: (p) => p.category === 'Bags',
  },
];

const REVIEWS = [
  {
    title: 'Better than jackets I bought in London',
    body: 'Ordered the Cafe Racer with custom sleeve measurements. The sheepskin is soft and smells like real leather. It reached Lahore in four days.',
    name: 'Hamza Qureshi',
    meta: 'Lahore · Verified buyer',
  },
  {
    title: 'The custom studio exceeded my expectations',
    body: 'I asked for a shearling aviator with brass hardware and my initials stamped inside. The team was patient and the fit is perfect.',
    name: 'Dr. Ayesha Siddiqui',
    meta: 'Islamabad · Custom order',
  },
  {
    title: 'Worth every rupee',
    body: 'The stitching and lining are far better than what I see in malls at twice the price. Delivery was free and the packaging was excellent.',
    name: 'Sana Malik',
    meta: 'Karachi · Verified buyer',
  },
];

const HomePage = () => {
  const { formatPrice } = useCurrency();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [tab, setTab] = useState('All');

  useEffect(() => {
    let alive = true;
    api
      .get('/products')
      .then((res) => alive && setProducts(res.data))
      .catch(() => alive && setError(true))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, []);

  const featured = useMemo(() => {
    const test = TABS.find((t) => t.key === tab).test;
    return [...products]
      .filter(test)
      .sort((a, b) => Number(!!b.bestSeller) - Number(!!a.bestSeller))
      .slice(0, 8);
  }, [products, tab]);

  const avgRating = useMemo(() => {
    const rated = products.filter((p) => p.rating > 0);
    return rated.length ? rated.reduce((a, p) => a + p.rating, 0) / rated.length : 0;
  }, [products]);

  const fromPrice = (test) => {
    const list = products.filter(test).map((p) => p.pricePKR);
    return list.length ? Math.min(...list) : null;
  };

  return (
    <>
      {/* HERO */}
      <section className="bg-stone">
        <div className="container-page grid items-center gap-8 py-10 md:grid-cols-2 md:gap-12 md:py-16 lg:py-20">
          <div className="order-2 md:order-1">
            <p className="mb-3 text-sm font-semibold text-saddle-600">Handmade in Lahore & Karachi</p>
            <h1 className="text-4xl font-semibold leading-[1.05] sm:text-5xl lg:text-6xl">
              Leather jackets cut to <span className="text-saddle-600">your measurements.</span>
            </h1>
            <p className="mt-5 max-w-lg text-base leading-relaxed text-ink-soft sm:text-lg">
              Full-grain leather, hand-finished by our pattern makers. Pick a ready-to-wear jacket, or have it made to fit you.
              Free delivery across Pakistan, with cash on delivery.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link to="/shop" className="btn-primary px-7 py-3.5">
                Shop jackets <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/custom-studio" className="btn-outline px-7 py-3.5">
                <Scissors className="h-4 w-4" /> Design your own
              </Link>
            </div>
            <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-ink-soft">
              <li className="flex items-center gap-2"><Truck className="h-4 w-4 text-saddle-600" /> Free delivery</li>
              <li className="flex items-center gap-2"><Ruler className="h-4 w-4 text-saddle-600" /> Free made-to-measure</li>
              <li className="flex items-center gap-2"><PackageCheck className="h-4 w-4 text-saddle-600" /> 30-day free alterations</li>
            </ul>
          </div>

          <div className="order-1 md:order-2">
            <div className="relative mx-auto aspect-[4/5] max-h-[560px] w-full max-w-md overflow-hidden rounded-2xl bg-stone-deep md:max-w-none">
              <img
                src="https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=1000&q=85"
                alt="Black leather cafe racer jacket"
                onError={imgFallback}
                className="h-full w-full object-cover"
                fetchPriority="high"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="container-page pt-14 sm:pt-20">
        <div className="mb-8 flex items-end justify-between gap-4">
          <h2 className="section-title">Shop by category</h2>
          <Link to="/shop" className="link hidden text-sm sm:inline">View all</Link>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-4">
          {TILES.map((t) => {
            const from = fromPrice(t.test);
            return (
              <Link key={t.label} to={t.to} className="group block">
                <div className="aspect-[4/5] overflow-hidden rounded-lg bg-stone">
                  <img
                    src={t.img}
                    alt=""
                    loading="lazy"
                    onError={imgFallback}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="mt-3 flex items-baseline justify-between gap-2">
                  <h3 className="font-sans text-base font-semibold sm:text-lg">{t.label}</h3>
                  <ArrowRight className="h-4 w-4 shrink-0 text-ink-muted transition-transform group-hover:translate-x-1" />
                </div>
                {from && <p className="text-sm text-ink-muted">From {formatPrice(from)}</p>}
              </Link>
            );
          })}
        </div>
      </section>

      {/* BESTSELLERS */}
      <section className="container-page pt-16 sm:pt-24">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <h2 className="section-title">Best sellers</h2>
          <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 sm:mx-0 sm:px-0" role="tablist" aria-label="Filter products">
            {TABS.map((t) => (
              <button
                key={t.key}
                role="tab"
                aria-selected={tab === t.key}
                onClick={() => setTab(t.key)}
                className={`chip shrink-0 ${tab === t.key ? 'chip-active' : ''}`}
              >
                {t.key}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 gap-x-3 gap-y-8 sm:gap-x-5 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i}>
                <div className="skeleton aspect-[4/5]" />
                <div className="skeleton mt-3 h-4 w-3/4" />
                <div className="skeleton mt-2 h-4 w-1/3" />
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="rounded-lg border border-line bg-stone/60 p-8 text-center">
            <p className="font-semibold">We couldn’t load the products.</p>
            <p className="mt-1 text-sm text-ink-muted">Please check that the server is running, then refresh the page.</p>
          </div>
        ) : featured.length === 0 ? (
          <p className="py-10 text-center text-ink-muted">No products in this category yet.</p>
        ) : (
          <div className="grid grid-cols-2 gap-x-3 gap-y-8 sm:gap-x-5 lg:grid-cols-4">
            {featured.map((p, i) => (
              <ProductCard key={p._id} product={p} priority={i < 4} />
            ))}
          </div>
        )}

        <div className="mt-10 text-center">
          <Link to="/shop" className="btn-outline px-8">View all products</Link>
        </div>
      </section>

      {/* CUSTOM STUDIO */}
      <section className="mt-16 bg-ink text-white sm:mt-24">
        <div className="container-page grid items-center gap-10 py-14 md:grid-cols-2 lg:py-20">
          <div className="overflow-hidden rounded-xl">
            <img
              src="https://images.unsplash.com/photo-1521223890158-f9f7c3d5d504?auto=format&fit=crop&w=1000&q=80"
              alt="Leather being measured and cut in our workshop"
              loading="lazy"
              onError={imgFallback}
              className="aspect-[4/3] w-full object-cover"
            />
          </div>
          <div>
            <h2 className="text-3xl font-semibold text-white sm:text-4xl">Design a jacket that fits only you</h2>
            <p className="mt-4 max-w-lg text-white/75">
              Choose the cut, leather, colour and hardware, then enter your measurements. Our pattern makers cut it by hand and deliver in 10–14 days.
            </p>
            <ol className="mt-7 space-y-4">
              {[
                ['Choose your style', 'Cafe racer, biker, shearling, trench or varsity.'],
                ['Enter your measurements', 'Or pick a standard size. Every measurement is checked before cutting.'],
                ['We make it and deliver', 'Free courier anywhere in Pakistan, with 30 days of free alterations.'],
              ].map(([t, d], i) => (
                <li key={t} className="flex gap-4">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white text-sm font-bold text-ink">{i + 1}</span>
                  <div>
                    <p className="font-semibold">{t}</p>
                    <p className="text-sm text-white/65">{d}</p>
                  </div>
                </li>
              ))}
            </ol>
            <Link to="/custom-studio" className="btn mt-8 bg-white px-7 py-3.5 text-ink hover:bg-saddle-100">
              Start designing <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* CRAFT */}
      <section className="container-page pt-16 sm:pt-24">
        <h2 className="section-title max-w-xl">Why people choose The Jacket Maker</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-3 sm:gap-6">
          {[
            [Layers, 'Full-grain leather', 'We use only the top layer of the hide. It breathes, lasts for decades and develops a patina as you wear it.'],
            [Scissors, 'Cut and sewn by hand', 'Every jacket is cut from a pattern made for it, then stitched and finished by one team in our workshop.'],
            [Truck, 'Delivered free, pay on arrival', 'Free courier across Pakistan. Pay by cash on delivery, bank transfer, JazzCash or EasyPaisa.'],
          ].map(([Icon, t, d]) => (
            <div key={t} className="rounded-lg border border-line p-6">
              <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-full bg-saddle-50">
                <Icon className="h-5 w-5 text-saddle-600" />
              </div>
              <h3 className="font-sans text-lg font-semibold">{t}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">{d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* REVIEWS */}
      <section className="container-page pt-16 sm:pt-24">
        <div className="mb-8 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <h2 className="section-title">What customers say</h2>
          {avgRating > 0 && (
            <div className="flex items-center gap-2 text-sm text-ink-soft">
              <Stars value={avgRating} size={16} /> <span className="font-semibold">{avgRating.toFixed(1)}</span> average product rating
            </div>
          )}
        </div>
        <div className="grid gap-4 md:grid-cols-3 md:gap-6">
          {REVIEWS.map((r) => (
            <figure key={r.name} className="flex flex-col rounded-lg bg-stone p-6">
              <Stars value={5} size={16} />
              <blockquote className="mt-3 flex-1">
                <p className="font-sans font-semibold">{r.title}</p>
                <p className="mt-2 text-sm leading-relaxed text-ink-soft">{r.body}</p>
              </blockquote>
              <figcaption className="mt-5 text-sm">
                <span className="font-semibold">{r.name}</span>
                <span className="block text-xs text-ink-muted">{r.meta}</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>
    </>
  );
};

export default HomePage;
