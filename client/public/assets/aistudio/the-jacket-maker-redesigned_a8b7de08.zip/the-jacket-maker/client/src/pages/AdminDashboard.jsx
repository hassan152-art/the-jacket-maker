import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, Plus, Trash2, X, Loader2, Package, Scissors, Banknote, Boxes } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';
import { Modal, EmptyState, imgFallback } from '../components/ui';
import api from '../services/api';

const ORDER_STATUSES = ['Processing', 'In Crafting', 'Dispatched', 'Delivered', 'Cancelled'];
const INQUIRY_STATUSES = ['New Request', 'Consultant Review', 'Quote Approved', 'In Crafting', 'Completed'];
const STATUS_STYLE = {
  Delivered: 'bg-ok/10 text-ok',
  Cancelled: 'bg-sale/10 text-sale',
  Dispatched: 'bg-blue-50 text-blue-700',
};
const EMPTY_FORM = { name: '', category: 'Men', subCategory: 'Cafe Racer', price: '', leather: 'Full Grain Sheepskin', image: '', description: '' };

const Stat = ({ icon: Icon, label, value, hint }) => (
  <div className="rounded-lg border border-line p-5">
    <div className="flex items-center gap-2 text-sm text-ink-muted"><Icon className="h-4 w-4" /> {label}</div>
    <p className="mt-2 font-display text-3xl font-semibold">{value}</p>
    {hint && <p className="mt-0.5 text-xs text-ink-muted">{hint}</p>}
  </div>
);

const AdminDashboard = () => {
  const { isAdmin, setIsAuthModalOpen, user } = useAuth();
  const { formatPrice } = useCurrency();

  const [stats, setStats] = useState(null);
  const [orders, setOrders] = useState([]);
  const [inquiries, setInquiries] = useState([]);
  const [products, setProducts] = useState([]);
  const [tab, setTab] = useState('orders');
  const [notice, setNotice] = useState(null);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [busy, setBusy] = useState(false);
  const [toDelete, setToDelete] = useState(null);

  const say = (type, text) => {
    setNotice({ type, text });
    setTimeout(() => setNotice(null), 3500);
  };

  const load = useCallback(async () => {
    try {
      const [s, o, i, p] = await Promise.all([
        api.get('/stats'),
        api.get('/orders'),
        api.get('/custom-studio/inquiries'),
        api.get('/products'),
      ]);
      setStats(s.data);
      setOrders(o.data);
      setInquiries(i.data);
      setProducts(p.data);
    } catch (err) {
      console.error('Failed to load admin data:', err);
      say('error', 'Couldn’t load dashboard data.');
    }
  }, []);

  useEffect(() => {
    if (isAdmin) load();
  }, [isAdmin, load]);

  if (!isAdmin) {
    return (
      <div className="container-page py-16">
        <EmptyState icon={ShieldCheck} title="Admins only" text={user ? 'Your account doesn’t have access to this page.' : 'Please sign in with an admin account to continue.'}>
          {!user && <button type="button" onClick={() => setIsAuthModalOpen(true)} className="btn-primary">Sign in</button>}
          <Link to="/" className="btn-outline">Back to store</Link>
        </EmptyState>
      </div>
    );
  }

  const updateOrder = async (id, status) => {
    try {
      await api.put(`/orders/${id}/status`, { status });
      say('ok', 'Order status updated.');
      load();
    } catch {
      say('error', 'Couldn’t update the order status.');
    }
  };
  const updateInquiry = async (id, status) => {
    try {
      await api.put(`/custom-studio/inquiries/${id}/status`, { status });
      say('ok', 'Inquiry status updated.');
      load();
    } catch {
      say('error', 'Couldn’t update the inquiry status.');
    }
  };

  const createProduct = async (e) => {
    e.preventDefault();
    setBusy(true);
    const price = Number(form.price);
    try {
      await api.post('/products', {
        name: form.name,
        category: form.category,
        subCategory: form.subCategory,
        description: form.description,
        pricePKR: price,
        priceUSD: Math.round(price / 280),
        leatherType: form.leather,
        images: [form.image || 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800'],
        sizes: ['XS', 'S', 'M', 'L', 'XL', '2XL'],
        colors: [{ name: 'Obsidian Black', hex: '#111111' }],
      });
      setShowAdd(false);
      setForm(EMPTY_FORM);
      say('ok', 'Product created.');
      load();
    } catch {
      say('error', 'Couldn’t create the product.');
    } finally {
      setBusy(false);
    }
  };

  const confirmDelete = async () => {
    try {
      await api.delete(`/products/${toDelete._id}`);
      say('ok', 'Product removed.');
      setToDelete(null);
      load();
    } catch {
      say('error', 'Couldn’t delete the product.');
    }
  };

  const sf = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const sel = 'input w-auto py-1.5 text-sm';

  return (
    <div className="container-page py-8 sm:py-12">
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-semibold">Admin dashboard</h1>
          <p className="text-sm text-ink-muted">Manage orders, custom inquiries and products.</p>
        </div>
        <button type="button" onClick={() => setShowAdd(true)} className="btn-primary self-start sm:self-auto"><Plus className="h-4 w-4" /> Add product</button>
      </div>

      {notice && (
        <p role="status" className={`mb-6 rounded-md px-4 py-3 text-sm ${notice.type === 'ok' ? 'bg-ok/10 text-ok' : 'bg-sale/10 text-sale'}`}>{notice.text}</p>
      )}

      {stats && (
        <div className="mb-8 grid grid-cols-2 gap-3 lg:grid-cols-4 sm:gap-4">
          <Stat icon={Banknote} label="Revenue" value={formatPrice(stats.totalRevenuePKR)} />
          <Stat icon={Package} label="Orders" value={stats.totalOrders} hint={`${stats.pendingOrdersCount} in progress`} />
          <Stat icon={Scissors} label="Custom inquiries" value={stats.customInquiriesCount} />
          <Stat icon={Boxes} label="Products" value={stats.totalProducts} />
        </div>
      )}

      <div role="tablist" className="mb-6 flex gap-1 overflow-x-auto border-b border-line no-scrollbar">
        {[['orders', `Orders (${orders.length})`], ['inquiries', `Custom inquiries (${inquiries.length})`], ['products', `Products (${products.length})`]].map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={`-mb-px shrink-0 border-b-2 px-4 py-3 text-sm font-semibold ${tab === k ? 'border-ink text-ink' : 'border-transparent text-ink-muted hover:text-ink'}`}>
            {l}
          </button>
        ))}
      </div>

      {/* ORDERS */}
      {tab === 'orders' && (
        orders.length === 0 ? (
          <EmptyState icon={Package} title="No orders yet" />
        ) : (
          <>
            <div className="hidden overflow-x-auto rounded-lg border border-line md:block">
              <table className="w-full text-left text-sm">
                <thead className="bg-stone text-xs text-ink-soft">
                  <tr>{['Code', 'Customer', 'Items', 'Total', 'Payment', 'Status'].map((h) => <th key={h} className="px-4 py-3 font-semibold">{h}</th>)}</tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {orders.map((o) => (
                    <tr key={o._id} className="align-top">
                      <td className="px-4 py-3 font-mono text-xs font-semibold">{o.trackingCode || o._id}</td>
                      <td className="px-4 py-3"><span className="block font-semibold">{o.customer?.name}</span><span className="text-xs text-ink-muted">{o.customer?.city} · {o.customer?.phone}</span></td>
                      <td className="max-w-[220px] px-4 py-3 text-xs">{o.orderItems?.map((it, i) => <div key={i} className="truncate">{it.quantity}× {it.name} ({it.size})</div>)}</td>
                      <td className="px-4 py-3 font-semibold">{formatPrice(o.totalPKR)}</td>
                      <td className="px-4 py-3 text-xs">{o.paymentMethod}</td>
                      <td className="px-4 py-3">
                        <select aria-label="Order status" value={o.orderStatus} onChange={(e) => updateOrder(o._id, e.target.value)} className={sel}>
                          {ORDER_STATUSES.map((s) => <option key={s}>{s}</option>)}
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <ul className="space-y-3 md:hidden">
              {orders.map((o) => (
                <li key={o._id} className="rounded-lg border border-line p-4 text-sm">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-mono text-xs font-semibold">{o.trackingCode || o._id}</p>
                      <p className="mt-1 font-semibold">{o.customer?.name}</p>
                      <p className="text-xs text-ink-muted">{o.customer?.city} · {o.customer?.phone}</p>
                    </div>
                    <p className="shrink-0 font-semibold">{formatPrice(o.totalPKR)}</p>
                  </div>
                  <div className="mt-3 space-y-0.5 text-xs text-ink-soft">{o.orderItems?.map((it, i) => <div key={i} className="truncate">{it.quantity}× {it.name} ({it.size})</div>)}</div>
                  <div className="mt-3 flex items-center justify-between gap-3">
                    <span className={`badge ${STATUS_STYLE[o.orderStatus] || 'bg-saddle-50 text-saddle-700'}`}>{o.paymentMethod}</span>
                    <select aria-label="Order status" value={o.orderStatus} onChange={(e) => updateOrder(o._id, e.target.value)} className={sel}>
                      {ORDER_STATUSES.map((s) => <option key={s}>{s}</option>)}
                    </select>
                  </div>
                </li>
              ))}
            </ul>
          </>
        )
      )}

      {/* INQUIRIES */}
      {tab === 'inquiries' && (
        inquiries.length === 0 ? (
          <EmptyState icon={Scissors} title="No custom inquiries yet" />
        ) : (
          <ul className="space-y-4">
            {inquiries.map((q) => (
              <li key={q._id} className="rounded-lg border border-line p-5 text-sm">
                <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
                  <div>
                    <p className="font-semibold">{q.customerName}</p>
                    <p className="text-xs text-ink-muted">{q.email} · {q.phone}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-semibold">{formatPrice(q.estimatedPricePKR)}</span>
                    <select aria-label="Inquiry status" value={q.status} onChange={(e) => updateInquiry(q._id, e.target.value)} className={sel}>
                      {INQUIRY_STATUSES.map((s) => <option key={s}>{s}</option>)}
                    </select>
                  </div>
                </div>
                <dl className="mt-4 grid grid-cols-2 gap-3 text-xs sm:grid-cols-4">
                  {[['Style', q.silhouette], ['Leather', q.leatherType], ['Colour', q.color], ['Hardware', q.hardware]].map(([k, v]) => (
                    <div key={k}><dt className="text-ink-muted">{k}</dt><dd className="font-semibold">{v}</dd></div>
                  ))}
                </dl>
                {q.measurements && Object.keys(q.measurements).length > 0 && (
                  <p className="mt-3 rounded bg-stone px-3 py-2 text-xs text-ink-soft">
                    Chest {q.measurements.chest}″ · Shoulders {q.measurements.shoulders}″ · Sleeves {q.measurements.sleeves}″ · Waist {q.measurements.waist}″
                  </p>
                )}
                {q.notes && <p className="mt-3 text-xs italic text-ink-soft">“{q.notes}”</p>}
              </li>
            ))}
          </ul>
        )
      )}

      {/* PRODUCTS */}
      {tab === 'products' && (
        <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((p) => (
            <li key={p._id} className="flex gap-3 rounded-lg border border-line p-3">
              <img src={p.images?.[0]} alt="" onError={imgFallback} className="h-24 w-[76px] shrink-0 rounded bg-stone object-cover" />
              <div className="min-w-0 flex-1 text-sm">
                <p className="text-xs text-ink-muted">{p.category} · {p.subCategory}</p>
                <p className="line-clamp-2 font-semibold">{p.name}</p>
                <p className="mt-1 font-semibold">{formatPrice(p.pricePKR)}</p>
              </div>
              <button type="button" onClick={() => setToDelete(p)} aria-label={`Delete ${p.name}`} className="self-start rounded p-2 text-ink-muted hover:bg-sale/10 hover:text-sale">
                <Trash2 className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      )}

      {/* ADD PRODUCT */}
      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Add product" maxWidth="max-w-lg">
        <div className="flex items-center justify-between border-b border-line px-5 py-4">
          <h2 className="text-xl font-semibold">Add product</h2>
          <button type="button" onClick={() => setShowAdd(false)} aria-label="Close" className="rounded-full p-2 hover:bg-stone"><X className="h-5 w-5" /></button>
        </div>
        <form onSubmit={createProduct} className="space-y-4 overflow-y-auto p-5">
          <div><label htmlFor="n-name" className="label">Product name</label><input id="n-name" required value={form.name} onChange={sf('name')} placeholder="e.g. Phoenix Burnished Biker Jacket" className="input" /></div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="n-cat" className="label">Category</label>
              <select id="n-cat" value={form.category} onChange={sf('category')} className="input">{['Men', 'Women', 'Bags', 'Accessories'].map((c) => <option key={c}>{c}</option>)}</select>
            </div>
            <div><label htmlFor="n-sub" className="label">Style</label><input id="n-sub" required value={form.subCategory} onChange={sf('subCategory')} className="input" /></div>
            <div><label htmlFor="n-price" className="label">Price (PKR)</label><input id="n-price" required type="number" min="1" value={form.price} onChange={sf('price')} className="input" /></div>
            <div><label htmlFor="n-leather" className="label">Leather</label><input id="n-leather" value={form.leather} onChange={sf('leather')} className="input" /></div>
          </div>
          <div><label htmlFor="n-img" className="label">Image URL</label><input id="n-img" type="url" value={form.image} onChange={sf('image')} placeholder="https://…" className="input" /></div>
          <div><label htmlFor="n-desc" className="label">Description</label><textarea id="n-desc" required rows={3} value={form.description} onChange={sf('description')} className="input" /></div>
          <div className="flex justify-end gap-3 pt-1">
            <button type="button" onClick={() => setShowAdd(false)} className="btn-ghost">Cancel</button>
            <button type="submit" disabled={busy} className="btn-primary">{busy && <Loader2 className="h-4 w-4 animate-spin" />} Create product</button>
          </div>
        </form>
      </Modal>

      {/* DELETE CONFIRM */}
      <Modal open={!!toDelete} onClose={() => setToDelete(null)} title="Delete product" maxWidth="max-w-sm">
        <div className="p-6">
          <h2 className="text-xl font-semibold">Delete this product?</h2>
          <p className="mt-2 text-sm text-ink-soft">“{toDelete?.name}” will be removed from the store. This can’t be undone.</p>
          <div className="mt-6 flex justify-end gap-3">
            <button type="button" onClick={() => setToDelete(null)} className="btn-ghost">Cancel</button>
            <button type="button" onClick={confirmDelete} className="btn bg-sale text-white hover:bg-sale/90">Delete</button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default AdminDashboard;
