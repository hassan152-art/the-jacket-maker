import React, { useState } from 'react';
import { X, Eye, EyeOff, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Modal } from './ui';

const AuthModal = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, login, register } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '', city: '' });
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const close = () => {
    setIsAuthModalOpen(false);
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (isLogin) await login(form.email, form.password);
      else await register(form);
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong. Please check your details and try again.');
    } finally {
      setLoading(false);
    }
  };

  const fillDemo = (email, password) => setForm((f) => ({ ...f, email, password }));

  return (
    <Modal open={isAuthModalOpen} onClose={close} title={isLogin ? 'Sign in' : 'Create account'} maxWidth="max-w-md">
      <div className="flex items-start justify-between px-6 pb-2 pt-6">
        <div>
          <h2 className="text-2xl font-semibold">{isLogin ? 'Welcome back' : 'Create your account'}</h2>
          <p className="mt-1 text-sm text-ink-muted">
            {isLogin ? 'Sign in to track orders and save your wishlist.' : 'Faster checkout and easy order tracking.'}
          </p>
        </div>
        <button type="button" onClick={close} aria-label="Close" className="-mr-2 -mt-1 rounded-full p-2 hover:bg-stone">
          <X className="h-5 w-5" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 overflow-y-auto px-6 pb-6 pt-3">
        {error && (
          <p role="alert" className="rounded-md border border-sale/30 bg-sale/5 px-3 py-2 text-sm text-sale">{error}</p>
        )}

        {!isLogin && (
          <div>
            <label htmlFor="a-name" className="label">Full name</label>
            <input id="a-name" required autoComplete="name" value={form.name} onChange={set('name')} className="input" />
          </div>
        )}

        <div>
          <label htmlFor="a-email" className="label">Email</label>
          <input id="a-email" type="email" required autoComplete="email" placeholder="name@example.com" value={form.email} onChange={set('email')} className="input" />
        </div>

        <div>
          <label htmlFor="a-pw" className="label">Password</label>
          <div className="relative">
            <input
              id="a-pw"
              type={showPw ? 'text' : 'password'}
              required
              minLength={isLogin ? undefined : 6}
              autoComplete={isLogin ? 'current-password' : 'new-password'}
              value={form.password}
              onChange={set('password')}
              className="input pr-11"
            />
            <button
              type="button"
              onClick={() => setShowPw((v) => !v)}
              aria-label={showPw ? 'Hide password' : 'Show password'}
              className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-ink-muted hover:text-ink"
            >
              {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>

        {!isLogin && (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="a-phone" className="label">Phone</label>
              <input id="a-phone" type="tel" autoComplete="tel" placeholder="03XX XXXXXXX" value={form.phone} onChange={set('phone')} className="input" />
            </div>
            <div>
              <label htmlFor="a-city" className="label">City</label>
              <input id="a-city" autoComplete="address-level2" value={form.city} onChange={set('city')} className="input" />
            </div>
          </div>
        )}

        <button type="submit" disabled={loading} className="btn-primary w-full">
          {loading && <Loader2 className="h-4 w-4 animate-spin" />}
          {isLogin ? 'Sign in' : 'Create account'}
        </button>

        <p className="text-center text-sm text-ink-muted">
          {isLogin ? 'New here?' : 'Already have an account?'}{' '}
          <button type="button" onClick={() => { setIsLogin(!isLogin); setError(''); }} className="link">
            {isLogin ? 'Create an account' : 'Sign in'}
          </button>
        </p>

        {/* Demo helper – remove before going live */}
        <div className="rounded-md bg-stone p-3 text-xs">
          <p className="mb-2 font-semibold text-ink-soft">Demo accounts (click to fill)</p>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => { setIsLogin(true); fillDemo('umar@thejacketmaker.pk', 'customer123'); }} className="chip">Customer</button>
            <button type="button" onClick={() => { setIsLogin(true); fillDemo('admin@thejacketmaker.pk', 'admin123'); }} className="chip">Admin</button>
          </div>
        </div>
      </form>
    </Modal>
  );
};

export default AuthModal;
