import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';

import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import { WishlistProvider } from './context/WishlistContext';
import { CurrencyProvider } from './context/CurrencyContext';

import Navbar from './components/Navbar';
import Footer from './components/Footer';
import CartDrawer from './components/CartDrawer';
import SearchModal from './components/SearchModal';
import AuthModal from './components/AuthModal';

import HomePage from './pages/HomePage';
import ShopPage from './pages/ShopPage';
import ProductDetailPage from './pages/ProductDetailPage';
import CustomStudioPage from './pages/CustomStudioPage';
import CheckoutPage from './pages/CheckoutPage';
import OrderTrackingPage from './pages/OrderTrackingPage';
import CustomerDashboard from './pages/CustomerDashboard';
import AdminDashboard from './pages/AdminDashboard';
import AboutPage from './pages/AboutPage';
import WishlistPage from './pages/WishlistPage';

/** Scroll to top on page change (but not when only the query string changes, e.g. filters). */
const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const NotFound = () => (
  <div className="container-page py-24 text-center">
    <p className="font-display text-7xl font-semibold text-saddle-600">404</p>
    <h1 className="mt-2 text-3xl font-semibold">Page not found</h1>
    <p className="mx-auto mt-2 max-w-md text-ink-muted">The page you’re looking for doesn’t exist or has moved.</p>
    <div className="mt-8 flex justify-center gap-3">
      <Link to="/" className="btn-primary">Back to home</Link>
      <Link to="/shop" className="btn-outline">Shop jackets</Link>
    </div>
  </div>
);

function App() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  return (
    <Router>
      <ScrollToTop />
      <CurrencyProvider>
        <AuthProvider>
          <WishlistProvider>
            <CartProvider>
              <div className="flex min-h-screen flex-col bg-white text-ink">
                <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[100] focus:rounded focus:bg-white focus:px-4 focus:py-2 focus:shadow-lg">
                  Skip to content
                </a>
                <Navbar onOpenSearch={() => setIsSearchOpen(true)} />

                <main id="main" className="flex-1">
                  <Routes>
                    <Route path="/" element={<HomePage />} />
                    <Route path="/shop" element={<ShopPage />} />
                    <Route path="/product/:slug" element={<ProductDetailPage />} />
                    <Route path="/custom-studio" element={<CustomStudioPage />} />
                    <Route path="/checkout" element={<CheckoutPage />} />
                    <Route path="/track-order" element={<OrderTrackingPage />} />
                    <Route path="/dashboard" element={<CustomerDashboard />} />
                    <Route path="/admin" element={<AdminDashboard />} />
                    <Route path="/about" element={<AboutPage />} />
                    <Route path="/wishlist" element={<WishlistPage />} />
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </main>

                <Footer />

                <CartDrawer />
                <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
                <AuthModal />
              </div>
            </CartProvider>
          </WishlistProvider>
        </AuthProvider>
      </CurrencyProvider>
    </Router>
  );
}

export default App;
