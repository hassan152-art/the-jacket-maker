import React, { useState, useEffect, useRef } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import {
  ShoppingBag,
  Heart,
  Search,
  User,
  Menu,
  X,
  ChevronDown,
  Scissors,
  ShieldCheck,
  Truck,
  LogOut,
  Package,
  Phone,
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';
import { useBodyLock, useEscape } from './ui';

const MEGA = {
  Men: {
    to: '/shop?category=Men',
    links: [
      ['All men’s jackets', '/shop?category=Men'],
      ['Biker jackets', '/shop?category=Men&subCategory=Biker'],
      ['Cafe racer jackets', '/shop?category=Men&subCategory=Cafe Racer'],
      ['Shearling & aviator', '/shop?category=Men&subCategory=Shearling'],
      ['Trench coats', '/shop?category=Men&subCategory=Trench Coats'],
      ['Varsity jackets', '/shop?category=Men&subCategory=Varsity'],
    ],
  },
  Women: {
    to: '/shop?category=Women',
    links: [
      ['All women’s jackets', '/shop?category=Women'],
      ['Biker jackets', '/shop?category=Women&subCategory=Biker'],
      ['Leather blazers', '/shop?category=Women&subCategory=Blazers'],
      ['Shearling coats', '/shop?category=Women&subCategory=Shearling'],
      ['Trench coats', '/shop?category=Women&subCategory=Trench Coats'],
    ],
  },
};

export const Logo = ({ light = false }) => (
  <Link to="/" className="flex items-center gap-2" aria-label="The Jacket Maker – home">
    <span className={`hidden min-[400px]:flex h-8 w-8 items-center justify-center rounded ${light ? 'bg-white text-ink' : 'bg-ink text-white'}`}>
      <Scissors className="h-4 w-4" />
    </span>
    <span className={`whitespace-nowrap font-display text-[17px] font-bold leading-none tracking-wide min-[400px]:text-xl sm:text-[22px] lg:text-xl 2xl:text-[22px] ${light ? 'text-white' : 'text-ink'}`}>
      THE JACKET MAKER
    </span>
  </Link>
);

const CurrencyToggle = ({ dark = false }) => {
  const { currency, setCurrency } = useCurrency();
  const base = dark ? 'text-white/70 hover:text-white' : 'text-ink-muted hover:text-ink';
  const active = dark ? 'bg-white text-ink' : 'bg-ink text-white';
  return (
    <div className="inline-flex items-center rounded border border-current/20 p-0.5 text-[11px] font-semibold" role="group" aria-label="Currency">
      {['PKR', 'USD'].map((c) => (
        <button
          key={c}
          type="button"
          onClick={() => setCurrency(c)}
          aria-pressed={currency === c}
          className={`rounded-sm px-2 py-0.5 transition-colors ${currency === c ? active : base}`}
        >
          {c}
        </button>
      ))}
    </div>
  );
};

const IconButton = ({ children, label, badge, ...props }) => (
  <button
    type="button"
    aria-label={label}
    className="relative flex h-10 w-10 items-center justify-center rounded-full text-ink transition-colors hover:bg-stone"
    {...props}
  >
    {children}
    {badge > 0 && (
      <span className="absolute right-0.5 top-0.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-saddle-600 px-1 text-[10px] font-bold text-white">
        {badge > 99 ? '99+' : badge}
      </span>
    )}
  </button>
);

const Navbar = ({ onOpenSearch }) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userOpen, setUserOpen] = useState(false);
  const [mobileSection, setMobileSection] = useState(null);
  const userRef = useRef(null);
  const location = useLocation();

  const { totalItemsCount, setIsCartOpen } = useCart();
  const { wishlistCount } = useWishlist();
  const { user, logout, setIsAuthModalOpen, isAdmin } = useAuth();

  useBodyLock(mobileOpen);
  useEscape(mobileOpen, () => setMobileOpen(false));
  useEscape(userOpen, () => setUserOpen(false));

  // Close everything on navigation
  useEffect(() => {
    setMobileOpen(false);
    setUserOpen(false);
  }, [location.pathname, location.search]);

  // Close user menu when clicking outside
  useEffect(() => {
    if (!userOpen) return undefined;
    const onDown = (e) => userRef.current && !userRef.current.contains(e.target) && setUserOpen(false);
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [userOpen]);

  // Close the mobile menu if the viewport grows to desktop size
  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    const onChange = (e) => e.matches && setMobileOpen(false);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  const category = new URLSearchParams(location.search).get('category');
  const isShop = location.pathname === '/shop';
  const topLink = 'relative flex h-16 whitespace-nowrap items-center gap-1 px-2.5 text-sm font-semibold text-ink xl:px-3 transition-colors hover:text-saddle-600';
  const underline =
    'after:absolute after:inset-x-2.5 after:bottom-0 after:h-0.5 after:bg-saddle-600 after:content-[""]';

  return (
    <>
      <header className="sticky top-0 z-40 w-full bg-white shadow-[0_1px_0_0_#E4E3DF]">
        {/* Utility bar */}
        <div className="bg-ink text-white">
          <div className="container-page flex h-9 items-center justify-between gap-4 text-xs">
            <p className="truncate font-medium">
              <span className="hidden sm:inline">Free delivery across Pakistan · Cash on delivery · Made to your measurements</span>
              <span className="sm:hidden">Free delivery · Cash on delivery</span>
            </p>
            <div className="hidden items-center gap-5 md:flex">
              <a href="tel:+924235789120" className="hidden items-center gap-1.5 whitespace-nowrap text-white/80 hover:text-white lg:flex">
                <Phone className="h-3.5 w-3.5" /> +92 (042) 3578-9120
              </a>
              <Link to="/track-order" className="flex items-center gap-1.5 whitespace-nowrap text-white/80 hover:text-white">
                <Truck className="h-3.5 w-3.5" /> Track order
              </Link>
              <CurrencyToggle dark />
            </div>
          </div>
        </div>

        {/* Main bar */}
        <nav className="container-page relative flex h-16 items-center justify-between gap-3" aria-label="Main">
          {/* Left: burger (mobile) */}
          <div className="flex shrink-0 items-center lg:hidden">
            <IconButton label="Open menu" onClick={() => setMobileOpen(true)} aria-expanded={mobileOpen}>
              <Menu className="h-6 w-6" />
            </IconButton>
          </div>

          {/* Logo: centered on mobile, left on desktop */}
          <div className="flex min-w-0 flex-1 justify-center lg:flex-none lg:justify-start">
            <Logo />
          </div>

          {/* Desktop links */}
          <ul className="hidden items-center lg:flex">
            {Object.entries(MEGA).map(([label, cfg]) => (
              <li key={label} className="group relative">
                <Link to={cfg.to} className={`${topLink} ${isShop && category === label ? underline : ''}`}>
                  {label}
                  <ChevronDown className="h-3.5 w-3.5 text-ink-muted transition-transform group-focus-within:rotate-180 group-hover:rotate-180" />
                </Link>
                <div className="invisible absolute left-0 top-full z-50 w-60 opacity-0 transition-all duration-150 group-focus-within:visible group-focus-within:opacity-100 group-hover:visible group-hover:opacity-100">
                  <ul className="rounded-b-lg border border-line bg-white py-2 shadow-xl">
                    {cfg.links.map(([text, to]) => (
                      <li key={text}>
                        <Link to={to} className="block px-4 py-2 text-sm text-ink-soft hover:bg-stone hover:text-ink">
                          {text}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              </li>
            ))}
            <li>
              <Link to="/shop?category=Bags" className={`${topLink} ${isShop && category === 'Bags' ? underline : ''}`}>
                Bags
              </Link>
            </li>
            <li>
              <NavLink to="/custom-studio" className={({ isActive }) => `${topLink} ${isActive ? underline : ''}`}>
                Custom studio
                <span className="hidden rounded bg-saddle-50 px-1.5 py-0.5 text-[10px] font-bold text-saddle-600 2xl:inline">Made to measure</span>
              </NavLink>
            </li>
            <li>
              <NavLink to="/about" className={({ isActive }) => `${topLink} ${isActive ? underline : ''}`}>
                Our craft
              </NavLink>
            </li>
          </ul>

          {/* Right: actions */}
          <div className="flex shrink-0 items-center justify-end gap-0.5">
            <button
              type="button"
              onClick={onOpenSearch}
              className="mr-2 hidden h-10 w-44 items-center 2xl:w-56 gap-2 rounded-full border border-line-strong bg-stone/60 px-4 text-sm text-ink-muted transition-colors hover:border-ink xl:flex"
              aria-label="Search products"
            >
              <Search className="h-4 w-4" /> Search jackets, bags…
            </button>
            <span className="xl:hidden">
              <IconButton label="Search" onClick={onOpenSearch}>
                <Search className="h-5 w-5" />
              </IconButton>
            </span>

            <Link
              to="/wishlist"
              aria-label={`Wishlist${wishlistCount ? `, ${wishlistCount} items` : ''}`}
              className="relative hidden h-10 w-10 items-center justify-center rounded-full text-ink hover:bg-stone sm:flex"
            >
              <Heart className="h-5 w-5" />
              {wishlistCount > 0 && (
                <span className="absolute right-0.5 top-0.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-saddle-600 px-1 text-[10px] font-bold text-white">
                  {wishlistCount}
                </span>
              )}
            </Link>

            {/* Account (desktop) */}
            <div className="relative hidden lg:block" ref={userRef}>
              {user ? (
                <>
                  <button
                    type="button"
                    onClick={() => setUserOpen((v) => !v)}
                    aria-haspopup="menu"
                    aria-expanded={userOpen}
                    className="flex h-10 items-center gap-2 whitespace-nowrap rounded-full pl-1.5 pr-2.5 text-sm font-semibold hover:bg-stone"
                  >
                    <span className="flex h-7 w-7 items-center justify-center rounded-full bg-saddle-600 text-xs font-bold text-white">
                      {user.name?.charAt(0).toUpperCase()}
                    </span>
                    <span className="max-w-[80px] truncate">{user.name?.split(' ')[0]}</span>
                    <ChevronDown className="h-3.5 w-3.5 text-ink-muted" />
                  </button>
                  {userOpen && (
                    <div role="menu" className="absolute right-0 top-full mt-2 w-60 animate-fade-in overflow-hidden rounded-lg border border-line bg-white shadow-xl">
                      <div className="border-b border-line px-4 py-3">
                        <p className="text-xs text-ink-muted">Signed in as</p>
                        <p className="truncate text-sm font-semibold">{user.email}</p>
                        {isAdmin && <span className="badge mt-1.5 bg-saddle-50 text-saddle-700">Admin</span>}
                      </div>
                      <Link role="menuitem" to="/dashboard" className="flex items-center gap-2.5 px-4 py-2.5 text-sm hover:bg-stone">
                        <Package className="h-4 w-4 text-ink-muted" /> My orders & profile
                      </Link>
                      {isAdmin && (
                        <Link role="menuitem" to="/admin" className="flex items-center gap-2.5 px-4 py-2.5 text-sm hover:bg-stone">
                          <ShieldCheck className="h-4 w-4 text-ink-muted" /> Admin dashboard
                        </Link>
                      )}
                      <button
                        role="menuitem"
                        type="button"
                        onClick={() => {
                          logout();
                          setUserOpen(false);
                        }}
                        className="flex w-full items-center gap-2.5 border-t border-line px-4 py-2.5 text-left text-sm text-sale hover:bg-stone"
                      >
                        <LogOut className="h-4 w-4" /> Sign out
                      </button>
                    </div>
                  )}
                </>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsAuthModalOpen(true)}
                  aria-label="Sign in"
                  className="flex h-10 items-center gap-2 whitespace-nowrap rounded-full px-3 text-sm font-semibold hover:bg-stone"
                >
                  <User className="h-5 w-5" /> <span className="hidden 2xl:inline">Sign in</span>
                </button>
              )}
            </div>

            <IconButton label={`Open bag, ${totalItemsCount} items`} badge={totalItemsCount} onClick={() => setIsCartOpen(true)}>
              <ShoppingBag className="h-5 w-5" />
            </IconButton>
          </div>
        </nav>
      </header>

      {/* Mobile drawer – rendered OUTSIDE <header> so `fixed` is relative to the viewport */}
      {mobileOpen && (
        <div className="fixed inset-0 z-[55] lg:hidden" role="dialog" aria-modal="true" aria-label="Menu">
          <div className="absolute inset-0 animate-fade-in bg-ink/60" onClick={() => setMobileOpen(false)} />
          <div className="relative flex h-full w-[88%] max-w-sm animate-slide-in-left flex-col bg-white shadow-2xl">
            <div className="flex h-16 shrink-0 items-center justify-between border-b border-line px-4">
              <Logo />
              <IconButton label="Close menu" onClick={() => setMobileOpen(false)}>
                <X className="h-6 w-6" />
              </IconButton>
            </div>

            <div className="flex-1 overflow-y-auto overscroll-contain">
              <ul className="divide-y divide-line">
                {Object.entries(MEGA).map(([label, cfg]) => {
                  const open = mobileSection === label;
                  return (
                    <li key={label}>
                      <button
                        type="button"
                        onClick={() => setMobileSection(open ? null : label)}
                        aria-expanded={open}
                        className="flex w-full items-center justify-between px-5 py-4 text-left text-base font-semibold"
                      >
                        {label}
                        <ChevronDown className={`h-5 w-5 text-ink-muted transition-transform ${open ? 'rotate-180' : ''}`} />
                      </button>
                      {open && (
                        <ul className="bg-stone/60 pb-2">
                          {cfg.links.map(([text, to]) => (
                            <li key={text}>
                              <Link to={to} className="block px-8 py-3 text-sm text-ink-soft">
                                {text}
                              </Link>
                            </li>
                          ))}
                        </ul>
                      )}
                    </li>
                  );
                })}
                <li><Link to="/shop?category=Bags" className="block px-5 py-4 text-base font-semibold">Bags</Link></li>
                <li>
                  <Link to="/custom-studio" className="flex items-center justify-between px-5 py-4 text-base font-semibold">
                    Custom studio
                    <span className="rounded bg-saddle-50 px-2 py-0.5 text-[11px] font-bold text-saddle-600">Made to measure</span>
                  </Link>
                </li>
                <li><Link to="/about" className="block px-5 py-4 text-base font-semibold">Our craft</Link></li>
                <li><Link to="/track-order" className="flex items-center gap-2 px-5 py-4 text-base font-semibold"><Truck className="h-5 w-5 text-ink-muted" /> Track order</Link></li>
                <li>
                  <Link to="/wishlist" className="flex items-center gap-2 px-5 py-4 text-base font-semibold">
                    <Heart className="h-5 w-5 text-ink-muted" /> Wishlist {wishlistCount > 0 && <span className="text-sm text-ink-muted">({wishlistCount})</span>}
                  </Link>
                </li>
              </ul>
            </div>

            <div className="shrink-0 space-y-3 border-t border-line bg-white p-4 pb-safe">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-ink-muted">Currency</span>
                <CurrencyToggle />
              </div>
              {user ? (
                <div className="space-y-2">
                  <p className="truncate text-sm">
                    Signed in as <strong>{user.name}</strong>
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    <Link to="/dashboard" className="btn-outline btn-sm">My account</Link>
                    {isAdmin ? (
                      <Link to="/admin" className="btn-outline btn-sm">Admin</Link>
                    ) : (
                      <button type="button" onClick={logout} className="btn-outline btn-sm">Sign out</button>
                    )}
                  </div>
                  {isAdmin && (
                    <button type="button" onClick={logout} className="btn-ghost btn-sm w-full text-sale">Sign out</button>
                  )}
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setMobileOpen(false);
                    setIsAuthModalOpen(true);
                  }}
                  className="btn-primary w-full"
                >
                  <User className="h-4 w-4" /> Sign in / Create account
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Navbar;
