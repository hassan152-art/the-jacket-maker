import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { useCurrency } from '../context/CurrencyContext';
import { Stars, imgFallback } from './ui';

const ProductCard = ({ product, priority = false }) => {
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const { formatPrice } = useCurrency();
  const [colorIdx, setColorIdx] = useState(0);
  const [added, setAdded] = useState('');

  const liked = isInWishlist(product._id || product.slug);
  const colors = product.colors || [];
  const sizes = product.sizes || [];
  const onSale = product.originalPricePKR > product.pricePKR;
  const second = product.images?.[1];

  const quickAdd = (size) => {
    addToCart(product, { size, color: colors[colorIdx]?.name, quantity: 1 });
    setAdded(size);
    setTimeout(() => setAdded(''), 1200);
  };

  return (
    <article className="group relative flex flex-col">
      <div className="relative aspect-[4/5] overflow-hidden rounded-lg bg-stone">
        <Link to={`/product/${product.slug}`} className="block h-full w-full" aria-label={product.name}>
          <img
            src={product.images?.[0]}
            alt={product.name}
            loading={priority ? 'eager' : 'lazy'}
            onError={imgFallback}
            className={`h-full w-full object-cover transition-opacity duration-300 ${second ? 'md:group-hover:opacity-0' : 'transition-transform duration-500 md:group-hover:scale-105'}`}
          />
          {second && (
            <img
              src={second}
              alt=""
              loading="lazy"
              onError={(e) => (e.currentTarget.style.display = 'none')}
              className="absolute inset-0 hidden h-full w-full object-cover opacity-0 transition-opacity duration-300 md:block md:group-hover:opacity-100"
            />
          )}
        </Link>

        {/* badges */}
        <div className="pointer-events-none absolute left-2 top-2 flex flex-col items-start gap-1">
          {onSale && product.discountPercent > 0 && <span className="badge bg-sale text-white">−{product.discountPercent}%</span>}
          {product.bestSeller && <span className="badge bg-ink text-white">Best seller</span>}
          {product.isNewArrival && <span className="badge bg-white text-ink shadow-sm">New</span>}
        </div>

        {/* wishlist */}
        <button
          type="button"
          onClick={() => toggleWishlist(product)}
          aria-pressed={liked}
          aria-label={liked ? 'Remove from wishlist' : 'Add to wishlist'}
          className="absolute right-2 top-2 flex h-9 w-9 items-center justify-center rounded-full bg-white/95 shadow-sm transition-transform hover:scale-105"
        >
          <Heart className={`h-[18px] w-[18px] ${liked ? 'fill-sale text-sale' : 'text-ink'}`} />
        </button>

        {/* quick add: desktop hover / keyboard focus */}
        {sizes.length > 0 && (
          <div className="absolute inset-x-0 bottom-0 hidden translate-y-full bg-white/95 p-3 transition-transform duration-200 group-focus-within:translate-y-0 group-hover:translate-y-0 md:block">
            <p className="mb-2 text-center text-xs font-semibold text-ink-soft">
              {added ? `Added size ${added} to bag` : 'Quick add — choose size'}
            </p>
            <div className="flex flex-wrap justify-center gap-1.5">
              {sizes.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => quickAdd(s)}
                  className={`min-w-[2.25rem] rounded border px-2 py-1.5 text-xs font-semibold transition-colors ${added === s ? 'border-ok bg-ok text-white' : 'border-line-strong hover:border-ink hover:bg-ink hover:text-white'}`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="mt-3 flex flex-1 flex-col">
        <p className="text-xs text-ink-muted">{product.subCategory} · {product.leatherType}</p>
        <h3 className="mt-0.5 line-clamp-2 min-h-[2.5rem] font-sans text-sm font-semibold leading-5 sm:text-[15px]">
          <Link to={`/product/${product.slug}`} className="hover:text-saddle-600">{product.name}</Link>
        </h3>

        <div className="mt-1.5 flex items-center gap-1.5 text-xs text-ink-muted">
          <Stars value={product.rating || 0} size={13} />
          <span>({product.numReviews || 0})</span>
        </div>

        <div className="mt-2 flex flex-wrap items-baseline gap-x-2">
          <span className={`text-base font-semibold ${onSale ? 'text-sale' : ''}`}>{formatPrice(product.pricePKR)}</span>
          {onSale && <span className="text-xs text-ink-muted line-through">{formatPrice(product.originalPricePKR)}</span>}
        </div>

        {colors.length > 1 && (
          <div className="mt-2.5 flex items-center gap-1.5" role="group" aria-label="Colour">
            {colors.slice(0, 5).map((c, i) => (
              <button
                key={c.name}
                type="button"
                onClick={() => setColorIdx(i)}
                title={c.name}
                aria-label={c.name}
                aria-pressed={i === colorIdx}
                className={`h-4 w-4 rounded-full border border-black/15 ring-offset-2 transition ${i === colorIdx ? 'ring-2 ring-ink' : 'hover:ring-1 hover:ring-ink-muted'}`}
                style={{ backgroundColor: c.hex }}
              />
            ))}
          </div>
        )}
      </div>
    </article>
  );
};

export default ProductCard;
